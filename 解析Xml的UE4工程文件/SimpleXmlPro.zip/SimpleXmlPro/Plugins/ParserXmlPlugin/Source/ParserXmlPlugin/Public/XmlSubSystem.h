#pragma once
#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "XmlSubSystem.generated.h"
class UXmlObject;
UCLASS()
class PARSERXMLPLUGIN_API UXmlSubSystem :public UGameInstanceSubsystem
{
	GENERATED_BODY()
public:
	virtual bool ShouldCreateSubsystem(UObject* Outer)const override { return true; }

	/** Implement this for initialization of instances of the system */
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;

	/** Implement this for deinitialization of instances of the system */
	virtual void Deinitialize() override;
public:
	/**���ļ������xml����*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Construct Xml Object"), Category = "XmlParser|Subsystem")
	UXmlObject* LoadXmlFile(const FString& InXmlFilePath);

	/**��xml���ݴ洢��InXmlFilePath���Ŀ¼�£������ļ����ͺ�׺��*/
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Construct Xml Object"), Category = "XmlParser|Subsystem")
	bool SaveXmlFile(UXmlObject*InXmlObject, const FString& InXmlFilePath);
private:
	//����һ��UXmlObject����
	UXmlObject*	ConstructXmlObject();
};
