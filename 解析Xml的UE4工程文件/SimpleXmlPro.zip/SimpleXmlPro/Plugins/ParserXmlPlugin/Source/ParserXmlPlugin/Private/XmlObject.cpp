#include "XmlObject.h"
#include "XmlNodeValue.h"
#include "XmlFile.h"

bool UXmlObject::DecodeXml(const FString& InXmlFilePath)
{
	XmlFile = MakeShareable(new FXmlFile(InXmlFilePath));
	if (XmlFile->IsValid())
	{
		RootNode = NewObject<UXmlNodeValue>(this);
		//..
		RootNode->ParserXmlNode(XmlFile->GetRootNode());
		return true;
	}
	return false;
}

bool UXmlObject::EncodeJson(FString& OutStr) const
{
	if (XmlFile->IsValid())
	{
		OutStr = TEXT("<?xml version=\"1.0\" encoding=\"UTF-8\"?>") LINE_TERMINATOR;
		const FXmlNode* CurrentNode = XmlFile->GetRootNode();
		if (CurrentNode != nullptr)
		{
			UXmlNodeValue::WriteNodeHierarchy(*CurrentNode, FString(), OutStr);
			return true;
		}
	}
	return false;
}

bool UXmlObject::Save(const FString&InPath)
{
	FString OutStr;
	if (EncodeJson(OutStr))
	{
		if (FFileHelper::SaveStringToFile(OutStr, *InPath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM))
			return true;
	}
	return false;
}

UXmlNodeValue * UXmlObject::GetRootNode() const
{
	return RootNode;
}
