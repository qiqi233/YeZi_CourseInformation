#include "XmlSubsystem.h"
#include "XmlObject.h"

void UXmlSubSystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
}

void UXmlSubSystem::Deinitialize()
{
	Super::Deinitialize();
}

UXmlObject* UXmlSubSystem::LoadXmlFile(const FString& InXmlFilePath)
{
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (!PlatformFile.FileExists(*InXmlFilePath))
		return nullptr;
	UXmlObject* XmlObject = ConstructXmlObject();
	XmlObject->DecodeXml(InXmlFilePath);
	return XmlObject;
}
bool UXmlSubSystem::SaveXmlFile(UXmlObject*InXmlObject, const FString& InXmlFilePath)
{
	if (InXmlObject)
	{
		return InXmlObject->Save(InXmlFilePath);
	}
	return false;
}
UXmlObject* UXmlSubSystem::ConstructXmlObject()
{
	return NewObject<UXmlObject>(this);
}

