#include "XmlNodeValue.h"
#include "XmlNode.h"

UXmlNodeValue* UXmlNodeValue::GetNextNode()
{
	return NextNode;
}

const TArray<UXmlNodeValue*>& UXmlNodeValue::GetChildrenNodes()
{
	return Children;
}

UXmlNodeValue* UXmlNodeValue::GetFirstChildNode() const
{
	if (Children.Num() != 0)
	{
		return Children[0];
	}
	return nullptr;
}

UXmlNodeValue* UXmlNodeValue::FindChildNode(const FString& InTag)
{
	const int32 ChildCount = Children.Num();
	for (int32 ChildIndex = 0; ChildIndex < ChildCount; ++ChildIndex)
	{
		if (Children[ChildIndex] != nullptr && Children[ChildIndex]->GetTag() == InTag)
		{
			return Children[ChildIndex];
		}
	}
	return nullptr;
}

FString UXmlNodeValue::GetTag() const
{
	return XmlNodeValue->GetTag();	
}

FString UXmlNodeValue::GetContent() const
{
	return XmlNodeValue->GetContent();
}

void UXmlNodeValue::SetContent(const FString& InContent)
{
	XmlNodeValue->SetContent(InContent);
}

FString UXmlNodeValue::GetAttribute(const FString& InTag) const
{
	return XmlNodeValue->GetAttribute(InTag);
}

void UXmlNodeValue::AppendChildNode(const FString& InTag, const FString& InContent)
{
	XmlNodeValue->AppendChildNode(InTag, InContent);
}
void UXmlNodeValue::GetAttributes(TArray<FBPXmlAttribute>& BPXmlAttribute)
{
	BPXmlAttribute.Empty();
	for (const FXmlAttribute& XmlA : XmlNodeValue->GetAttributes())
	{
		FBPXmlAttribute TempAttribute;
		TempAttribute.Tag = XmlA.GetTag();
		TempAttribute.Value = XmlA.GetValue();
		BPXmlAttribute.Add(TempAttribute);
	}
}
FString UXmlNodeValue::EncodeNode()
{
	FString OutStr;
	WriteNodeHierarchy(*this->XmlNodeValue, FString(), OutStr);
	return OutStr;
}
void UXmlNodeValue::WriteNodeHierarchy(const FXmlNode& Node, const FString& Indent, FString& Output)
{
	// Write the tag
	Output += Indent + FString::Printf(TEXT("<%s"), *Node.GetTag());
	for (const FXmlAttribute& Attribute : Node.GetAttributes())
	{
		FString EscapedValue = Attribute.GetValue();
		EscapedValue.ReplaceInline(TEXT("&"), TEXT("&amp;"), ESearchCase::CaseSensitive);
		EscapedValue.ReplaceInline(TEXT("\""), TEXT("&quot;"), ESearchCase::CaseSensitive);
		EscapedValue.ReplaceInline(TEXT("'"), TEXT("&apos;"), ESearchCase::CaseSensitive);
		EscapedValue.ReplaceInline(TEXT("<"), TEXT("&lt;"), ESearchCase::CaseSensitive);
		EscapedValue.ReplaceInline(TEXT(">"), TEXT("&gt;"), ESearchCase::CaseSensitive);
		Output += FString::Printf(TEXT(" %s=\"%s\""), *Attribute.GetTag(), *EscapedValue);
	}

	// Write the node contents
	const FXmlNode* FirstChildNode = Node.GetFirstChildNode();
	if (FirstChildNode == nullptr)
	{
		const FString& Content = Node.GetContent();
		if (Content.Len() == 0)
		{
			Output += TEXT(" />") LINE_TERMINATOR;
		}
		else
		{
			Output += TEXT(">") + Content + FString::Printf(TEXT("</%s>"), *Node.GetTag()) + LINE_TERMINATOR;
		}
	}
	else
	{
		Output += TEXT(">") LINE_TERMINATOR;
		for (const FXmlNode* ChildNode = FirstChildNode; ChildNode != nullptr; ChildNode = ChildNode->GetNextNode())
		{
			WriteNodeHierarchy(*ChildNode, Indent + TEXT("\t"), Output);
		}
		Output += Indent + FString::Printf(TEXT("</%s>"), *Node.GetTag()) + LINE_TERMINATOR;
	}
}
void UXmlNodeValue::ParserXmlNode(FXmlNode* InNode)
{
	XmlNodeValue = InNode;
	for (FXmlNode* ChildNode : InNode->GetChildrenNodes())
	{
		UXmlNodeValue* TempXmlNode = NewObject<UXmlNodeValue>(this);
		TempXmlNode->XmlNodeValue = ChildNode;
		Children.Add(TempXmlNode);

		TempXmlNode->ParserXmlNode(ChildNode);
	}
	for (int32 i = 0; i < Children.Num(); ++i)
	{
		if (i < Children.Num() - 1) //4
		{
			Children[i]->NextNode=Children[i+1];
		}
		else
		{
			Children[i]->NextNode=nullptr;
		}
	}
}
