// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "SimpleXmlProGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class SIMPLEXMLPRO_API ASimpleXmlProGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
