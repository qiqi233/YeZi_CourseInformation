// Fill out your copyright notice in the Description page of Project Settings.


#include "MyActorComponent.h"
#include "XmlParser/Public/XmlFile.h"
#include "XmlParser/Public/XmlNode.h"

// Sets default values for this component's properties
UMyActorComponent::UMyActorComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UMyActorComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


bool UMyActorComponent::ReadXmlFile(const FString& InXmlFilePath)
{
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (!PlatformFile.FileExists(*InXmlFilePath))
		return false;

	TSharedPtr<FXmlFile> XmlFile = MakeShareable(new FXmlFile(InXmlFilePath));
	if (XmlFile.IsValid())
	{
		FXmlNode* RootNode = XmlFile->GetRootNode();
		for (FXmlNode* Child : RootNode->GetChildrenNodes())
		{
			FString category = Child->GetAttribute("category");
			GEngine->AddOnScreenDebugMessage(-1, 10, FColor::Purple, category);
			for (FXmlNode* SubChild : Child->GetChildrenNodes())
			{
				FString Content = SubChild->GetContent();
				GEngine->AddOnScreenDebugMessage(-1, 10, FColor::Black, Content);
			}
		}
	


	}

	return true;
}

// Called every frame
void UMyActorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

