#pragma once
#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "ThumbnailSubSystem.generated.h"

UCLASS()
class THUMBNAILTOOL_API UThumbnailSystem :public UGameInstanceSubsystem
{
	GENERATED_BODY()
public:
	virtual bool ShouldCreateSubsystem(UObject* Outer) const { return true; }

	/** Implement this for initialization of instances of the system */
	virtual void Initialize(FSubsystemCollectionBase& Collection);

	/** Implement this for deinitialization of instances of the system */
	virtual void Deinitialize();
public:
	UFUNCTION(BlueprintCallable,Category="Thumbnail System")
	void CaptureSceneImage(class UStaticMesh* InMesh,int32 SizeX, int32 SizeY);
private:
	TSharedPtr<class FModelPreviewScene> ModelPreviewScene;
};