#pragma once

#include "PreviewScene.h"

class FModelPreviewScene :public FPreviewScene
{
public:
	FModelPreviewScene(ConstructionValues CVS = ConstructionValues());
	void SetStaticMesh(class UStaticMesh* InMesh);
	void CaptureSceneImage(int32 SizeX, int32 SizeY);

protected:
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	void DrawCanvas(uint32 Width, uint32 Height, FRenderTarget* RenderTarget, FCanvas* Canvas);
	void CalculationView(FSceneViewFamily* ViewFamily, int32 X, int32 Y, uint32 SizeX, uint32 SizeY);
	void ConstructWorld();
private:
	void SerialiszeImage(int32 Width, int32 Height, const uint8 *Data, const FString& ImageName, bool bSaveJpgOnly = false);
	void SaveImage(UTextureRenderTarget2D *Texture, const FString& ImageName);
private:
	class AStaticMeshActor* MeshActor;
	//�ӿڷ���
	FRotator              ViewDir;
	//�ӿھ���۲����ݲ�
	float                 ViewZoom;
};