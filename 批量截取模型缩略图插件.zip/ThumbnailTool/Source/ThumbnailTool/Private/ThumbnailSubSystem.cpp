#include "ThumbnailSubSystem.h"
#include "ModelPreviewScene.h"
#include "Engine/StaticMesh.h"
void UThumbnailSystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
	if (!ModelPreviewScene.IsValid())
	{
		FModelPreviewScene::ConstructionValues CVS;
		CVS.bEditor = false;
		ModelPreviewScene = MakeShareable(new FModelPreviewScene(CVS));
	}
}

void UThumbnailSystem::Deinitialize()
{
	Super::Deinitialize();
	ModelPreviewScene = nullptr;
}

void UThumbnailSystem::CaptureSceneImage(UStaticMesh* InMesh, int32 SizeX, int32 SizeY)
{
	if (ModelPreviewScene.IsValid())
	{
		ModelPreviewScene->SetStaticMesh(InMesh);
		ModelPreviewScene->CaptureSceneImage(SizeX, SizeY);
	}
}

