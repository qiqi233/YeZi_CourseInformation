#include "UI/LabeBase.h"
#include "Components/Button.h"

ULabeBase::ULabeBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bIsOpenDetailPanel = false;
	LabelType = 0;
	bIsShowUI = true;
}

void ULabeBase::NativeConstruct()
{
	Super::NativeConstruct();
	if (MyButton)
	{
		MyButton->OnClicked.AddDynamic(this, &ULabeBase::OnClickEvent);
	}
}

void ULabeBase::NativeDestruct()
{
	Super::NativeDestruct();
	if (MyButton)
	{
		MyButton->OnClicked.RemoveAll(this);
	}
}

void ULabeBase::OnClickEvent()
{
	LabelBaseDelegate.ExecuteIfBound(this);
}

void ULabeBase::InitLabel(FVector InLoc, int32 InType /*= 0*/, bool InIsOpenDetail /*= false*/)
{
	Location = InLoc;
	LabelType = InType;
	bIsOpenDetailPanel = InIsOpenDetail;
	if (bIsOpenDetailPanel)
	{
		LabelBaseDelegate.ExecuteIfBound(this);
	}
}

void ULabeBase::SetLabelVisiable(bool InShowUI)
{
	if (bIsShowUI == InShowUI)
		return;
	bIsShowUI = InShowUI;
	if (bIsShowUI)
	{
		SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
}

void ULabeBase::Remove()
{
	RemoveDetailPanel();
	RemoveFromParent();
}
