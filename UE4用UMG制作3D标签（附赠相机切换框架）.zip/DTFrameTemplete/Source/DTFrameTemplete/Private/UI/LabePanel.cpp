#include "UI/LabePanel.h"
#include "LabeBase.h"
#include "Components/CanvasPanel.h"
#include "Kismet/GameplayStatics.h"
#include "Blueprint/WidgetLayoutLibrary.h"
#include "Components/CanvasPanelSlot.h"


ULabePanel::ULabePanel(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void ULabePanel::NativeConstruct()
{
	Super::NativeConstruct();
}

void ULabePanel::NativeDestruct()
{
	Super::NativeDestruct();

}

void ULabePanel::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::Tick(MyGeometry, InDeltaTime);

	for (ULabeBase* Label : LabelArray)
	{
		UWorld* const MyWorld = GetWorld();
		APlayerController* const PlayerController = UGameplayStatics::GetPlayerController(MyWorld, 0);
		if (PlayerController&&Label->IsValidLowLevel())
		{
			FVector2D ScreenPosition;
			//3D����ת����2D����ķ���
			bool success = PlayerController->ProjectWorldLocationToScreen(Label->Location, ScreenPosition);
			if (success)
			{
				const float ViewportScale = UWidgetLayoutLibrary::GetViewportScale(MyWorld);
				const float RelativeScale = FMath::Pow(ViewportScale, -1);
				ScreenPosition = ScreenPosition * RelativeScale;
				UCanvasPanelSlot* const PanelSlot = UWidgetLayoutLibrary::SlotAsCanvasSlot(Label);
				if (PanelSlot)
				{
					PanelSlot->SetPosition(ScreenPosition);

					if (Label->bIsShowUI)//���UI����ʾ״̬�Żᴥ��
						Label->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
				}
			}
			else
			{
				Label->SetVisibility(ESlateVisibility::Collapsed);
			}

		}
	}
	
}

ULabeBase* ULabePanel::CreateLabel(TSubclassOf<ULabeBase> InLabelClass, FVector InLocation, int32 InType /*= 0*/, bool bIsOpenDetail /*= false*/)
{
	ULabeBase*UI_Label = CreateWidget<ULabeBase>(this, InLabelClass);
	if (UI_Label)
	{
		MyCanvasPanel->AddChildToCanvas(UI_Label);
		UI_Label->LabelBaseDelegate.BindUObject(this, &ULabePanel::LabelButtonCallBack);
		UI_Label->InitLabel(InLocation, InType, bIsOpenDetail);
		LabelArray.Add(UI_Label);
		return UI_Label;
	}
	return nullptr;
}



void ULabePanel::LabelButtonCallBack(ULabeBase* InLabel)
{
	for (ULabeBase* Label : LabelArray)
	{
		if (Label->IsValidLowLevel())
		{
			if (Label == InLabel)
			{
				if (Label->bIsOpenDetailPanel)
				{
					//�ر���ϸ���
					Label->bIsOpenDetailPanel = false;
					Label->RemoveDetailPanel();
					//��������ӽ�
					Label->ReturnCamera();
					SetZOrder(Label,0);
					CurrentSelectLabel = nullptr;
				}
				else
				{
					//����ϸ���
					Label->bIsOpenDetailPanel = true;
					Label->CreateDetailPanel();
					//�۽�
					Label->FocusOnEvents(Label->Location);
					SetZOrder(Label, 100);
					CurrentSelectLabel = Label;
				}
			}
			else
			{
				if (Label->bIsOpenDetailPanel)
				{
					Label->bIsOpenDetailPanel = false;
					//������ǵ�ǰ�����Label, �Ƴ�������ϸ���
					Label->RemoveDetailPanel();
					SetZOrder(Label,0);
				}
			}
		}
	}
}


void ULabePanel::ShowLabelByType(int32 InType, bool bOnlyShowThisLabel/* = false*/)
{
	for (ULabeBase* Label : LabelArray)
	{
		if (Label->LabelType == InType)
		{
			Label->SetLabelVisiable(1);
		}
		else
		{
			if (bOnlyShowThisLabel)
			{
				Label->SetLabelVisiable(0);
			}
		}
	}
}

void ULabePanel::HiddenLabelByType(int32 InType, bool bOnlyHiddeThisLabel/* = false*/)
{
	for (ULabeBase* Label : LabelArray)
	{
		if (Label->LabelType == InType)
		{
			Label->SetLabelVisiable(0);
		}
		else
		{
			if (bOnlyHiddeThisLabel)
			{
				Label->SetLabelVisiable(1);
			}
		}
	}
}

void ULabePanel::ShowAllLabel()
{
	for (ULabeBase* Label : LabelArray)
	{
		Label->SetLabelVisiable(1);
	}
}

void ULabePanel::HiddenAllLabel()
{
	for (ULabeBase* Label : LabelArray)
	{
		Label->SetLabelVisiable(0);
	}
}

void ULabePanel::ClearAll()
{
	for (ULabeBase* Label : LabelArray)
	{
		Label->Remove();
	}
}

void ULabePanel::DeleteLabelByType(int32 InType)
{
	for (ULabeBase* Label : LabelArray)
	{
		if (Label->LabelType == InType)
			Label->Remove();
	}

}

void ULabePanel::ReturnCamera()
{
	LabelButtonCallBack(CurrentSelectLabel);
}

int32 ULabePanel::GetLabelNum() const
{
	return LabelArray.Num();
}

bool ULabePanel::HasLabel() const
{
	return GetLabelNum() > 0 ? 1 : 0;
}

int32 ULabePanel::GetLabelNumByType(int32 InType) const
{
	int32 num = 0;
	for (ULabeBase const * const Label : LabelArray)
	{
		if (Label->LabelType == InType)
			num++;
	}
	return num;
}

bool ULabePanel::HasLabelByType(int32 InType) const
{
	return GetLabelNumByType(InType) > 0 ? 1 : 0;
}

void ULabePanel::GetLabelsByType(int32 InType, TArray<ULabeBase*>& OutLabelArray) const
{
	for (ULabeBase* Label : LabelArray)
	{
		if (Label&&Label->LabelType == InType)
		{
			OutLabelArray.Add(Label);
		}
	}
}

void ULabePanel::GetLabels(TArray<ULabeBase*>& OutLabelArray) const
{
	OutLabelArray = LabelArray;
}

void ULabePanel::SetZOrder(UWidget* Label, int32 InZOrder)
{
	UCanvasPanelSlot* PanelSlot = UWidgetLayoutLibrary::SlotAsCanvasSlot(Label);
	if (PanelSlot)
	{
		PanelSlot->SetZOrder(InZOrder);
	}
}
