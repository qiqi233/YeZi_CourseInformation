#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "LabeBase.generated.h"

class UButton;
UCLASS()
class DTFRAMETEMPLETE_API ULabeBase :public UUserWidget
{
	GENERATED_UCLASS_BODY()
public:
	DECLARE_DELEGATE_OneParam(FLabelBaseDelegate, ULabeBase*);
public:
	virtual void NativeConstruct()override;
	virtual void NativeDestruct() override;
public:
	UPROPERTY(meta = (BindWidget))
	UButton* MyButton;

	FLabelBaseDelegate LabelBaseDelegate;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Label Base")
	FVector Location;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Label Base")
	bool bIsOpenDetailPanel;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Label Base")
	bool bIsShowUI;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Label Base")
	int32 LabelType;

public:
	UFUNCTION()
	void OnClickEvent();
public:
	//�������ǩ,�����۽��¼�
	UFUNCTION(BlueprintImplementableEvent)
	void FocusOnEvents(FVector InLoc);
	//�������ǩ,���������¼�
	UFUNCTION(BlueprintImplementableEvent)
	void ReturnCamera();
	//������ϸ����¼�
	UFUNCTION(BlueprintImplementableEvent)
	void CreateDetailPanel();
	//������ϸ����¼�
	UFUNCTION(BlueprintImplementableEvent)
	void RemoveDetailPanel();
public:
	UFUNCTION()
	void InitLabel(FVector InLoc, int32 InType = 0, bool InIsOpenDetail = false);
	void SetLabelVisiable(bool InShowUI);
	UFUNCTION()
	void Remove();
};
