#include "SubTask.h"
#include "HttpModule.h"
#include "AsyncDownloadFile.h"
#include "Misc/App.h"
#include "Misc/FileHelper.h"

FSubHttpTask::FSubHttpTask()
	:TaskID(INDEX_NONE)
	, bFinished(false)
	, StarPos(0)
	, Size(0)
	, bWaitResponse(false)
{

}

FSubHttpTask::~FSubHttpTask()
{
	Stop();
}

TSharedPtr<IHttpRequest> FSubHttpTask::CreateRequest()
{
	RequestPtr = FHttpModule::Get().CreateRequest();
	RequestPtr->SetURL(URL);
	RequestPtr->SetVerb(TEXT("GET"));
	RequestPtr->SetHeader(TEXT("Range"), Range);//�ϵ��������ظ��ļ���һ��Ƭ�� ����һ��Range����Χ��
	bWaitResponse = true;
	RequestTime = FApp::GetCurrentTime();//��ǰ����ʱ��
	return RequestPtr;
}

void FSubHttpTask::Stop()
{
	if (RequestPtr.IsValid())
	{
		RequestPtr->CancelRequest();
		RequestPtr = nullptr;
	}
}

void FSubHttpTask::SaveData()
{
	//hcf  http Cache file
	FString SubTaskFileName = MD5Str + TEXT("_") + FString::FromInt(TaskID) + TEXT(".hcf");

	FFileHelper::SaveArrayToFile(RawData, *(CurFilePath / SubTaskFileName));
}

void FSubHttpTask::LoadData()
{
	//hcf  http Cache file
	FString SubTaskFileName = MD5Str + TEXT("_") + FString::FromInt(TaskID) + TEXT(".hcf");
	FFileHelper::LoadFileToArray(RawData, *(CurFilePath / SubTaskFileName));
}


