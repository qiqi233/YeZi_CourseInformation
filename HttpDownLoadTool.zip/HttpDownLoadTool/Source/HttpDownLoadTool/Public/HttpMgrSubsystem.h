#pragma once
#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "Tickable.h"
#include "HttpMgrSubsystem.generated.h"


UCLASS(config = Game, defaultconfig, meta = (DisplayName = "HttpMgrSetting"))
class HTTPDOWNLOADTOOL_API UHttpManagerSetting :public UDeveloperSettings
{
	GENERATED_UCLASS_BODY()
public:
	UPROPERTY(config, EditAnywhere, Category = "Config | HttpManager")
	int32						MaxParallel;//�������ز�����
	UPROPERTY(config, EditAnywhere, Category = "Config | HttpManager")
	int32						MaxTryCount;//������������
	UPROPERTY(config, EditAnywhere, Category = "Config | HttpManager")
	int32						RequestKBSize;//ÿ��������Ĵ�С
	UPROPERTY(config, EditAnywhere, Category = "Config | HttpManager")
	float						ResponseTimeout;//����ʱ��ʱ��
	UPROPERTY(config, EditAnywhere, Category = "Config | HttpManager")
	FString						CurFilePath; //���ļ��Ļ���λ��
};
class UAsyncDownloadFile;
UCLASS()
class UHttpMgrSubsystem :public UGameInstanceSubsystem, public FTickableGameObject
{
	GENERATED_BODY()
public:
	virtual bool ShouldCreateSubsystem(UObject* Outer) const { return true; }

	/** Implement this for initialization of instances of the system */
	virtual void Initialize(FSubsystemCollectionBase& Collection);

	/** Implement this for deinitialization of instances of the system */
	virtual void Deinitialize();

	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override;
	virtual TStatId GetStatId() const { return TStatId();/* RETURN_QUICK_DECLARE_CYCLE_STAT(UHttpDownloadSubsystem, STATGROUP_Tickables);*/ }
public:
	UAsyncDownloadFile* CreateDownTask(
		UObject *WorldContextObject, 
		const FString &Url, 
		const FString &FileName, 
		const FString &Directory,
		bool bClearCache);

	void ExecDownloadTasks();

	void NotifyFailed(UAsyncDownloadFile *HttpFile, bool bForceFailed);

	void NotifyFinised(UAsyncDownloadFile *HttpFile);
	void ClearMgr();
private:
	void Init();
public:

	int32						MaxParallel;
	int32						MaxTryCount;
	int32						RequestKBSize;
	float						ResponseTimeout;
	FString						CurFilePath;
	UPROPERTY()
	TArray<UAsyncDownloadFile *>	DownloadHttpFiles;
};