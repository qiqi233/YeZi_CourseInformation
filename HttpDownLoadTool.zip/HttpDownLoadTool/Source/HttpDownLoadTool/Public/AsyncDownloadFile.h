#pragma once
#include "CoreMinimal.h"
#include "Kismet/BlueprintAsyncActionBase.h"
#include "UObject/Object.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "SubTask.h"
#include "AsyncDownloadFile.generated.h"


DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FHttpDownloadDelegate, const FString &, DestPathOrMsg, float, Progress);

UENUM(BlueprintType)
enum class ETaskState : uint8
{
	_Ready,
	_Downloading,
	_Succees,
	_Retry,
	_Failed,
};
class UHttpMgrSubsystem;
UCLASS()
class UAsyncDownloadFile :public UBlueprintAsyncActionBase
{
	GENERATED_UCLASS_BODY()
public:
	friend UHttpMgrSubsystem;
	/**
	*@param InUrl;http file url
	*@param InFileName: file name without path
	*@param InDirectory: directory name
	*@param bClearCache:whether to clean up cached files after file download is complete
	*/
	UFUNCTION(BlueprintCallable, Category = "HttpDownloader", meta = (WorldContext = "WorldContextObject"))
		static UAsyncDownloadFile *DownLoadHttpFile(
			UObject *WorldContextObject, 
			const FString& InUrl, 
			const FString& InFileName, 
			const FString &InDirectory, 
			bool bClearCache = false);
protected:
	void StartDownloadTake();
	void RequestFileSize();
	void HandleResponseFileSize(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded);

	void StartSubTaskDownload(TSharedRef<FSubHttpTask> SubHttpTask);
	void HandleDownload(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded,int32 TaskID);
	void UpdateProgress();

private:
	/**
	 * �㲥����ʧ��
	 */
	void  NotifyFailed();
	/**
	 * �㲥�������ȴ��׶�
	 */
	void  NotifyWait();
	/**
	* ��ʼ����������
	*/
	void BeginDownload();
	/**
	* ����������
	*/
	void CreateSubTask();
	void UpdateTask();
	/**
	* ����ļ����������
	*/
	void OnFinished();
	/**
	 * ��������ʱ��������
	 */
	void CheckDeadTask(double CurTime);
	/**
	 * �����ļ�
	 */
	void SaveToFile();
	/**
	* ��������
	*/
	void FatalErr(const FString &ErrString);
public:
	UPROPERTY(BlueprintAssignable)
	FHttpDownloadDelegate OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FHttpDownloadDelegate OnWait;

	UPROPERTY(BlueprintAssignable)
	FHttpDownloadDelegate OnFail;

	UPROPERTY(BlueprintAssignable)
	FHttpDownloadDelegate OnProgress;

	UPROPERTY(BlueprintAssignable)
	FHttpDownloadDelegate OnCancel;

protected:
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	ETaskState				State;//����״̬
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	int32					TryCount;//����Դ���
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	FString					Url;//���ص�ַ
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	FString					FileName;//�ļ���
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	FString					Directory;//�ļ�·��
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	float					Progress;//���ؽ���
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	int32					CurFileSize;//��ǰ�����˶��ٸ��ֽ���
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	int64					TotalFileSize;//http�ļ����ܴ�С

	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	int32					MaxTask;//���������
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	FString					MD5Str;// MD5 ��URL�Ƕ�Ӧ��ϵ
	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	bool					bClearCache;//������ɺ��Ƿ���������

	UPROPERTY(Transient, BlueprintReadOnly, Category = "HttpDownloader")
	int32 WaitResponse;
	UPROPERTY()
	UHttpMgrSubsystem*	Mgr;

	TSharedPtr<IHttpRequest> FileSizeRequest;
	TArray<TSharedPtr<FSubHttpTask>>	SubTasks;
};