// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "TestPictureProGameModeBase.generated.h"


/**
 * 
 */
UCLASS()
class TESTPICTUREPRO_API ATestPictureProGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:
	//virtual void BeginPlay() override;

};
//class FResAWM;
//class FUserUZI
//{
//public:
//	FUserUZI()
//	{
//		FResAWM* AWM = new FResAWM;
//		TSharedPtr<FResAWM>sss = AWM->AsShared();
//	}
//	void Upadate(const TSharedPtr<FResAWM>& AWM);
//};
//class FResAWM :public TSharedFromThis<FResAWM>
//{
//public:
//	FResAWM()
//	{
//		HP = 100;
//	}
//	void NotifyUpadate()
//	{
//		HP = 80;
//		FUserUZI UserUZI;
//		UserUZI.Upadate(this->AsShared());// 2
//	}
//	int32 GetHp() const
//	{
//		return HP;
//	}
//	~FResAWM();
//public:
//	int32 HP;
//
//};