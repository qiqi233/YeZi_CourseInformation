// Copyright Epic Games, Inc. All Rights Reserved.

#include "TestPicturePro.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TestPicturePro, "TestPicturePro" );
