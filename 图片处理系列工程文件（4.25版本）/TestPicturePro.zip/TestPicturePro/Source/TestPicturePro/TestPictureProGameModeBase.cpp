﻿// Copyright Epic Games, Inc. All Rights Reserved.


#include "TestPictureProGameModeBase.h"
//class FTestA
//{
//public:
//	FTestA()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("Hello FTestA"));
//	}
//	void TestFun()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("我是TestFun"));
//	}
//	~FTestA()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("FTestA:啊~ 我没了！！！"));
//	}
//};
//
//class FResBase
//{
//public:
//
//	FResBase()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("我是资源基类"));
//	}
//	void TestFun()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("我是基类的方法，子类也可以使用"));
//	}
//	~FResBase()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("FResBase:啊~ 我没了！！！"));
//	}
//};
//class FResUZI :public FResBase
//{
//public:
//	FResUZI()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("我是UZI冲锋枪"));
//	}
//	void TestDeviceFun()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("我是派生类的方法，只能我自己使用"));
//	}
//	~FResUZI()
//	{
//		UE_LOG(LogTemp, Warning, TEXT("FResUZI:啊~ 永远滴神！！！"));
//	}
//};
//
//class IAnimal
//{
//public:
//	// 克制
//	virtual void SetRestraint(const TSharedPtr<IAnimal>& InWhatAnimal) = 0;
//	virtual ~IAnimal() {}
//};
//class FLion;
//class FMouse;
//class FElephant :public IAnimal//大象
//{
//public:
//	FElephant()
//	{
//		UE_LOG(LogTemp, Warning, TEXT(" 我是大象，我克制狮子"));
//	}
//	virtual void SetRestraint(const TSharedPtr<IAnimal>& InWhatAnimal)
//	{
//		Lion = StaticCastSharedPtr<FLion>(InWhatAnimal);
//
//	}
//	virtual ~FElephant()
//	{
//		UE_LOG(LogTemp, Warning, TEXT(" 大象: 啊~我没了..."));
//	}
//public:
//	TSharedPtr<FLion> Lion;//-1
//
//};
//class FLion :public IAnimal //狮子
//{
//public:
//	FLion()
//	{
//		UE_LOG(LogTemp, Warning, TEXT(" 我是狮子，我克制老鼠"));
//	}
//	virtual void SetRestraint(const TSharedPtr<IAnimal>& InWhatAnimal)
//	{
//		Mouse = StaticCastSharedPtr<FMouse>(InWhatAnimal);
//	}
//	virtual ~FLion()
//	{
//		UE_LOG(LogTemp, Warning, TEXT(" 狮子: 啊~我没了..."));
//	}
//public:
//	TSharedPtr<FMouse> Mouse; //-1
//};
//class FMouse :public IAnimal	//老鼠
//{
//public:
//	FMouse()
//	{
//		UE_LOG(LogTemp, Warning, TEXT(" 我是老鼠，我克制大象"));
//	}
//	virtual void SetRestraint(const TSharedPtr<IAnimal>& InWhatAnimal)
//	{
//		Elephant = StaticCastSharedPtr<FElephant>(InWhatAnimal);
//	}
//	virtual ~FMouse()
//	{
//		UE_LOG(LogTemp, Warning, TEXT(" 老鼠: 啊~我没了..."));
//	}
//public:
//	TWeakPtr<FElephant> Elephant;
//};
//void ATestPictureProGameModeBase::BeginPlay()
//{
//	//共享指针 TSharedPtr<T>
//	{
//		////1.创建共享指针
//		//TSharedPtr<FTestA> TestPtr = MakeShareable(new FTestA());//引用计数=1
//		////2.判断是否有效
//		//if (TestPtr.IsValid())
//		//{
//		//	TestPtr->TestFun();
//		//}
//		////3.获取引用计数
//		//int32 Count = TestPtr.GetSharedReferenceCount();
//		//UE_LOG(LogTemp, Warning, TEXT("Count=%d"), Count);
//		////4.解引用
//		////FTestA* TestA = TestPtr.Get();
//		////手动释放
//		////TestPtr = nullptr;
//		//TestPtr.Reset();
//	}
//	//引用计数 = 0
//
//	//共享引用
//	{
//		////1.创建共享引用
//		//TSharedRef<FTestA> TestPtr = MakeShareable(new FTestA);//隐式转化//引用计数=1
//		////TSharedRef<FTestA> TestPtr1(TestPtr);//引用计数=2
//		////TSharedRef<FTestA> TestPtr=nullptr;//错误
//		//int32 Count = TestPtr.GetSharedReferenceCount();
//		//TestPtr.Get();
//		//TestPtr->TestFun();
//		//if (TestPtr.IsUnique())//true
//		//{
//		//	
//		//}
//	}
//
//	//如何相互转化
//	{
//		////共享引用转化成共享指针
//		//{
//		//	TSharedRef<FTestA> TestRef = MakeShareable(new FTestA);
//		//	TSharedPtr<FTestA> TestPtr = TestRef;
//		//}
//		////共享指针转化成共享引用
//		//{
//		//	TSharedPtr<FTestA> TestPtr = MakeShareable(new FTestA);
//		//	TSharedRef<FTestA> TestRef = TestPtr.ToSharedRef();
//		//}
//	}
//
//	//共享指针父子级之间的转化
//	{
//		//TSharedPtr<FResBase> Res = MakeShareable(new FResUZI);//多态
//		//if (Res.IsValid())
//		//{
//		//	Res->TestFun();
//		//	TSharedPtr<FResUZI> ResUZI = StaticCastSharedPtr<FResUZI>(Res);
//		//	if (ResUZI.IsValid())
//		//	{
//		//		ResUZI->TestDeviceFun();
//		//	}
//		//	//...
//
//		//}
//		//const TSharedPtr<FResBase> ConstRes = MakeShareable(new FResUZI);//多态
//		//if (ConstRes.IsValid())
//		//{
//			
//		//	TSharedPtr<FResBase> Res = ConstCastSharedPtr<FResBase>(ConstRes);
//		//}
//	}
//	//共享引用之间的转化
//	{
//		//StaticCastSharedPtr----StaticCastSharedRef
//		//ConstCastSharedPtr-----ConstCastSharedRef
//	}
//
//
//	//{
//	//	TSharedPtr<FElephant> Elephant = MakeShareable(new FElephant);//大象 引用计数=1
//	//	TSharedPtr<FLion> Lion = MakeShareable(new FLion);//狮子 引用计数=1
//	//	TSharedPtr<FMouse> Mouse = MakeShareable(new FMouse);//老鼠 引用计数=1
//
//	//	Elephant->SetRestraint(Lion); //引用计数 = 2
//
//	//	Lion->SetRestraint(Mouse);//引用计数 = 2
//
//	//	Mouse->SetRestraint(Elephant);//引用计数 = 2
//
//	//	int32 ElephantCount = 0;
//	//	int32 LionCount = 0;
//	//	int32 MouseCount = 0;
//	//	ElephantCount = Elephant.GetSharedReferenceCount();
//	//	LionCount = Lion.GetSharedReferenceCount();
//	//	MouseCount = Mouse.GetSharedReferenceCount();
//	//	UE_LOG(LogTemp, Warning, TEXT("引用计数：ElephantCount=%d\n LionCount=%d\n MouseCount=%d\n"), ElephantCount, LionCount, MouseCount);
//	//}
//	//弱指针的用法
//	//1.弱指针不能影响强指针的引用计数
//	//2.在使用弱指针时，需要对其进行检测，判断其是否有效
//	//3.弱指针最大的用途就是解决环形引用的问题
//	//4.弱指针另一个作用就是，不对资源进行竞争。只能使用资源，却没有权限控制资源的生命周期
//
//
//	Super::BeginPlay();
//}