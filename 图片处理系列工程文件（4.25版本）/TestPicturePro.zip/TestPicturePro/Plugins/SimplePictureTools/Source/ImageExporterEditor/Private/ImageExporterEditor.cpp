#include "ImageExporterEditor.h"

#define LOCTEXT_NAMESPACE "FSimplePictureToolsModule"
void FImageExporterEditorModule::StartupModule()
{

}

void FImageExporterEditorModule::ShutdownModule()
{

}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FImageExporterEditorModule, ImageExporterEditor)