#include "ImageExportTool.h"
#include "IImageWrapper.h"
#include "IImageWrapperModule.h"

UImageExportTool::UImageExportTool(const FObjectInitializer& Object)
	:Super(Object)
{
	SupportedClass = UTexture::StaticClass();
	FormatExtension.Add(TEXT("JPG"));
	FormatExtension.Add(TEXT("PNG"));
	FormatExtension.Add(TEXT("jpg"));
	FormatExtension.Add(TEXT("png"));
	FormatDescription.Add(TEXT("Export png"));
	FormatDescription.Add(TEXT("Export jpg"));
	FormatDescription.Add(TEXT("Export PNG"));
	FormatDescription.Add(TEXT("Export JPG"));
}

bool UImageExportTool::SupportsObject(UObject* Object) const
{
	if (Super::SupportsObject(Object))
	{
		const UTexture2D* Tex = Cast<UTexture2D>(Object);
		return Tex;
	}
	return false;
}

bool UImageExportTool::ExportBinary(UObject* Object, const TCHAR* Type, FArchive& Ar, FFeedbackContext* Warn, int32 FileIndex /*= 0*/, uint32 PortFlags /*= 0*/)
{
	UTexture2D* Texture = CastChecked<UTexture2D>(Object);
	check(Texture);
	const ETextureSourceFormat SourceFormat = Texture->Source.GetFormat();
	const ERGBFormat ExportFormat = ERGBFormat::BGRA;
	const int32 ExportBitDepth = SourceFormat == ETextureSourceFormat::TSF_RGBA16 ? 16 : 8;

	IImageWrapperModule& ImageWrapperModule = FModuleManager::Get().LoadModuleChecked<IImageWrapperModule>(TEXT("ImageWrapper"));
	TSharedPtr<IImageWrapper> ImageWrapper = nullptr;
	FString TypeStr(Type);

	if (TypeStr.Equals(TEXT("png"))|| TypeStr.Equals(TEXT("PNG")))
	{
		ImageWrapper = ImageWrapperModule.CreateImageWrapper(EImageFormat::PNG);
	}
	else if (TypeStr.Equals(TEXT("jpg")) || TypeStr.Equals(TEXT("JPG")))
	{
		ImageWrapper = ImageWrapperModule.CreateImageWrapper(EImageFormat::JPEG);
	}
	TArray64<uint8> RawData;
	Texture->Source.GetMipData(RawData, 0);

	if (ImageWrapper.IsValid() && ImageWrapper->SetRaw(RawData.GetData(), RawData.GetAllocatedSize(), Texture->Source.GetSizeX(), Texture->Source.GetSizeY(), ExportFormat, ExportBitDepth))
	{
		const TArray64<uint8>& CompressedData = ImageWrapper->GetCompressed(100);
		if (CompressedData.Num() != 0)
		{
			Ar.Serialize((void*)CompressedData.GetData(), CompressedData.GetAllocatedSize());
			return true;
		}
	}

	return false;
}
