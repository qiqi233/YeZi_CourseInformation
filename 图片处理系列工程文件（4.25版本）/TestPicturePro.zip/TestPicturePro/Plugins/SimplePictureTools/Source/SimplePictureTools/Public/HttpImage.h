// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/Image.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "HttpImage.generated.h"

/**
 * 
 */
UCLASS()
class SIMPLEPICTURETOOLS_API UHttpImage : public UImage
{
	GENERATED_BODY()
public:
	UHttpImage();
	virtual TSharedRef<SWidget> RebuildWidget() override;
public:
	UPROPERTY(EditAnywhere, Category = "HttpImageSetting")
	FString ImageURL;//ͼƬ���ص�ַ
	UPROPERTY(EditAnywhere, Category = "HttpImageSetting")
	bool bIsAutoRefresh;//�Ƿ��Զ�ˢ��ͼƬ
	UPROPERTY(EditAnywhere, Category = "HttpImageSetting")
	bool bIsForceRefresh;//�Ƿ�ǿ�Ƹ���ͼƬ

public:
	UFUNCTION(BlueprintCallable, Category = "HttpImage")
	void UpdateImageByURL(const FString& InURL);
protected:
	void SendRequest();
	void OnCompleteRequest(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bConnectedSuccessfully);
private:
	UPROPERTY()
	FString ImagePath;//����·��
};
