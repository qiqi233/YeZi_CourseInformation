#include "PictureToolsLibrary.h"
#include "IImageWrapperModule.h"
#include "IImageWrapper.h"
#include "BmpImageSupport.h"
#include "Engine/Texture2DDynamic.h"
#include "Engine/Texture.h"
#include "AssetRegistryModule.h"

bool ExportBmp(UTexture* Texture, FArchive& Ar)
{
	if (!Texture->Source.IsValid() || (Texture->Source.GetFormat(0) != TSF_BGRA8 && Texture->Source.GetFormat(0) != TSF_RGBA16 && Texture->Source.GetFormat() != TSF_G8))
	{
		return false;
	}

	const bool bIsRGBA16 = Texture->Source.GetFormat(0) == TSF_RGBA16;
	const bool bIsG8 = Texture->Source.GetFormat(0) == TSF_G8;
	const int32 SourceBytesPerPixel = bIsRGBA16 ? 8 : (bIsG8 ? 1 : 4);


	int32 SizeX = Texture->Source.GetSizeX();
	int32 SizeY = Texture->Source.GetSizeY();
	TArray64<uint8> RawData;
	Texture->Source.GetMipData(RawData, 0, 0);

	FBitmapFileHeader bmf;
	FBitmapInfoHeader bmhdr;

	// File header.
	bmf.bfType = 'B' + (256 * (int32)'M');
	bmf.bfReserved1 = 0;
	bmf.bfReserved2 = 0;
	int32 biSizeImage = SizeX * SizeY * 3;
	bmf.bfOffBits = sizeof(FBitmapFileHeader) + sizeof(FBitmapInfoHeader);
	bmhdr.biBitCount = 24;

	bmf.bfSize = bmf.bfOffBits + biSizeImage;
	Ar << bmf;

	// Info header.
	bmhdr.biSize = sizeof(FBitmapInfoHeader);
	bmhdr.biWidth = SizeX;
	bmhdr.biHeight = SizeY;
	bmhdr.biPlanes = 1;
	bmhdr.biCompression = 0;
	bmhdr.biSizeImage = biSizeImage;
	bmhdr.biXPelsPerMeter = 0;
	bmhdr.biYPelsPerMeter = 0;
	bmhdr.biClrUsed = 0;
	bmhdr.biClrImportant = 0;
	Ar << bmhdr;


	// Upside-down scanlines.
	for (int32 i = SizeY - 1; i >= 0; i--)
	{
		uint8* ScreenPtr = &RawData[i*SizeX*SourceBytesPerPixel];
		for (int32 j = SizeX; j > 0; j--)
		{
			if (bIsRGBA16)
			{
				Ar << ScreenPtr[1];
				Ar << ScreenPtr[3];
				Ar << ScreenPtr[5];
				ScreenPtr += 8;
			}
			else if (bIsG8)
			{
				Ar << ScreenPtr[0];
				Ar << ScreenPtr[0];
				Ar << ScreenPtr[0];
				ScreenPtr += 1;
			}
			else
			{
				Ar << ScreenPtr[0];
				Ar << ScreenPtr[1];
				Ar << ScreenPtr[2];
				ScreenPtr += 4;
			}
		}
	}
	return true;
}

bool UPictureToolsLibrary::LoadImageToTexture2D(const FString& ImagePath, UTexture2D* &InTexture, float& Width, float& Height)
{
	TArray64<uint8> OutRawData;
	if(LoadImageToData(ImagePath, OutRawData,Width,Height))
	{
		InTexture = UTexture2D::CreateTransient(Width, Height, PF_B8G8R8A8);
		if (InTexture)
		{
			void * TextureData = InTexture->PlatformData->Mips[0].BulkData.Lock(LOCK_READ_WRITE);
			FMemory::Memcpy(TextureData, OutRawData.GetData(), OutRawData.Num());
			InTexture->PlatformData->Mips[0].BulkData.Unlock();
			InTexture->UpdateResource();
			return true;
		}
	}

	return false;
}


bool UPictureToolsLibrary::LoadImageToData(const FString& ImagePath, TArray64<uint8>&OutData, float& Width, float& Height)
{
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (!PlatformFile.FileExists(*ImagePath))
	{
		return false;
	}
	//ȡ��ͼƬ�Ķ���������
	TArray<uint8> ImageResultData;
	FFileHelper::LoadFileToArray(ImageResultData, *ImagePath);

	//����ͼƬ��ʽ
	FString Ex = FPaths::GetExtension(ImagePath, false);
	EImageFormat ImageFormat = EImageFormat::Invalid;
	if (Ex.Equals(TEXT("jpg"), ESearchCase::IgnoreCase) || Ex.Equals(TEXT("jpeg"), ESearchCase::IgnoreCase))
	{
		ImageFormat = EImageFormat::JPEG;
	}
	else if (Ex.Equals(TEXT("png"), ESearchCase::IgnoreCase) )
	{
		ImageFormat = EImageFormat::PNG;
	}
	else if (Ex.Equals(TEXT("bmp"), ESearchCase::IgnoreCase) )
	{
		ImageFormat = EImageFormat::BMP;
	}
	//����ͼƬ����ģ��
	IImageWrapperModule&ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>("ImageWrapper");
	//���ݲ�ͬ��ͼƬ��ʽ������ͬ��ͼƬ������ľ���ʵ��
	TSharedPtr<IImageWrapper> ImageWrapperPtr = ImageWrapperModule.CreateImageWrapper(ImageFormat);
	if (ImageWrapperPtr.IsValid() && ImageWrapperPtr->SetCompressed(ImageResultData.GetData(), ImageResultData.GetAllocatedSize()))
	{
		//OutData ���ʽ�޹ص���ɫ����
		ImageWrapperPtr->GetRaw(ERGBFormat::BGRA, 8, OutData);
		Width = ImageWrapperPtr->GetWidth();
		Height = ImageWrapperPtr->GetHeight();
		return true;
	}
	return false;
}

bool UPictureToolsLibrary::LoadImageToDyTexture2D(const FString& ImagePath, UTexture2DDynamic* &InDyTexture, float& Width, float& Height)
{
	TArray64<uint8> *OutData = new TArray64<uint8>();//����ʽ�޹ص���ɫ����	
	if (LoadImageToData(ImagePath, *OutData, Width, Height))
	{
		InDyTexture = UTexture2DDynamic::Create(Width, Height);
		if (InDyTexture)
		{
			//���Ϊfalse����ʾ����ʹ��Alphaͨ����Ϊ����
			InDyTexture->SRGB = true;
			//Ϊ��������һ���µ���Դ�����Ҹ��¶Ը���Դ�����л�������
			InDyTexture->UpdateResource();
			float i = 1.2;
			FTexture2DDynamicResource* Texture2DDyRes = static_cast<FTexture2DDynamicResource*>(InDyTexture->Resource);
			ENQUEUE_RENDER_COMMAND(FWriterRawDataToDyTexture2D)
				([Texture2DDyRes, OutData](FRHICommandListImmediate&RHICommandList) mutable
			{
				//��Texture2DDyRes��ֵ
				check(IsInRenderingThread());
				FRHITexture2D* RHITexture2D=Texture2DDyRes->GetTexture2DRHI();
				int64 width= RHITexture2D->GetSizeX();
				int64 height= RHITexture2D->GetSizeY();
				//����̬��ͼ��ֵ
				uint32 DestStride = 0;//Ŀ�경��
				//����
				uint8* DestData=reinterpret_cast<uint8*>(RHILockTexture2D(RHITexture2D, 0, RLM_WriteOnly, DestStride, false, false));
				for (int64 y = 0; y < height; ++y)
				{
					int64 DestPtrStride = y * DestStride;
					uint8* DestPtr = &DestData[DestPtrStride];

					uint8* StrData = OutData->GetData();

					int64 SrcPtrStride = y * width;
					const FColor* SrcPtr = &((FColor*)(StrData))[SrcPtrStride];
					for (int64 x = 0; x < width; ++x)
					{
						*DestPtr++ = SrcPtr->B;
						*DestPtr++ = SrcPtr->G;
						*DestPtr++ = SrcPtr->R;
						*DestPtr++ = SrcPtr->A;
						SrcPtr++;
					}
				}

				RHIUnlockTexture2D(RHITexture2D, 0, false, false);	
				if (OutData)
				{
					delete OutData;
					OutData = nullptr;
				}
			}
			);
		}



	}

	return true;
}

bool UPictureToolsLibrary::SaveImageFromTexture2D(UTexture2D* InTex, const FString& DesPath)
{
	if (!InTex)
		return false;
	FString Ex = FPaths::GetExtension(DesPath, false);
	EImageFormat ImageFormat = EImageFormat::Invalid;
	if (Ex.Equals(TEXT("jpg"), ESearchCase::IgnoreCase) || Ex.Equals(TEXT("jpeg"), ESearchCase::IgnoreCase))
	{
		ImageFormat = EImageFormat::JPEG;
	}
	else if (Ex.Equals(TEXT("png"), ESearchCase::IgnoreCase))
	{
		ImageFormat = EImageFormat::PNG;
	}
	else if (Ex.Equals(TEXT("bmp"), ESearchCase::IgnoreCase))
	{
		ImageFormat = EImageFormat::BMP;
	}
	IImageWrapperModule& ImageWrapperModule = FModuleManager::LoadModuleChecked<IImageWrapperModule>("ImageWrapper");

	TSharedPtr<IImageWrapper>ImageWrapperPtr=ImageWrapperModule.CreateImageWrapper(ImageFormat);
	TArray64<uint8> OutData;
	InTex->Source.GetMipData(OutData,0);
	float Width = InTex->GetSizeX();
	float Height = InTex->GetSizeY();
	int Depth = InTex->Source.GetFormat()== ETextureSourceFormat::TSF_RGBA16? 16 : 8;
	if (ImageWrapperPtr.IsValid() && ImageWrapperPtr->SetRaw(OutData.GetData(), OutData.GetAllocatedSize(), Width, Height, ERGBFormat::BGRA, Depth))
	{
		if (ImageFormat == EImageFormat::BMP)
		{
			FArchive *Archive = IFileManager::Get().CreateFileWriter(*DesPath);
			if (Archive&&Archive->IsSaving())
			{
				ExportBmp(InTex, *Archive);
				Archive->Close();
			}		
		}
		else
		{
			const TArray64<uint8>CompessedData = ImageWrapperPtr->GetCompressed(100);
			FFileHelper::SaveArrayToFile(CompessedData, *DesPath);
		}
		return true;
	}
	return true;
}



bool UPictureToolsLibrary::CreateTexture2DAsset(const FString& ImagePath)
{

	TArray64<uint8> OutRawData;
	float TextureWidth{};
	float TextureHeight{};
	if (LoadImageToData(ImagePath, OutRawData, TextureWidth, TextureHeight))
	{
		FString TextureName = FPaths::GetBaseFilename(ImagePath);
		FString PackageName = TEXT("/Game/ProceduralTextures/");
		PackageName += TextureName;
		UPackage* Package = CreatePackage(NULL, *PackageName);
		Package->FullyLoad();

		UTexture2D* NewTexture = NewObject<UTexture2D>(Package, *TextureName, RF_Public | RF_Standalone | RF_MarkAsRootSet);

		NewTexture->AddToRoot();				// This line prevents garbage collection of the texture
		NewTexture->PlatformData = new FTexturePlatformData();	// Then we initialize the PlatformData
		NewTexture->PlatformData->SizeX = TextureWidth;
		NewTexture->PlatformData->SizeY = TextureHeight;
		NewTexture->PlatformData->SetNumSlices(1);
		NewTexture->PlatformData->PixelFormat = EPixelFormat::PF_B8G8R8A8;		
		// Allocate first mipmap.
		FTexture2DMipMap* Mip = new(NewTexture->PlatformData->Mips) FTexture2DMipMap();
		Mip->SizeX = TextureWidth;
		Mip->SizeY = TextureHeight;

		// Lock the texture so it can be modified
		Mip->BulkData.Lock(LOCK_READ_WRITE);
		uint8* TextureData = (uint8*)Mip->BulkData.Realloc(OutRawData.Num());
		FMemory::Memcpy(TextureData, OutRawData.GetData(), OutRawData.Num());
		Mip->BulkData.Unlock();

		NewTexture->MipGenSettings = TMGS_NoMipmaps;
		NewTexture->Source.Init(TextureWidth, TextureHeight, 1, 1, ETextureSourceFormat::TSF_BGRA8, OutRawData.GetData());

		NewTexture->UpdateResource();
		Package->MarkPackageDirty();
		FAssetRegistryModule::AssetCreated(NewTexture);

		FString PackageFileName = FPackageName::LongPackageNameToFilename(PackageName, FPackageName::GetAssetPackageExtension());
		bool bSaved = UPackage::SavePackage(Package, NewTexture, EObjectFlags::RF_Public | EObjectFlags::RF_Standalone, *PackageFileName, GError, nullptr, true, true, SAVE_NoError);
		return bSaved;
	}
	return false;
}
