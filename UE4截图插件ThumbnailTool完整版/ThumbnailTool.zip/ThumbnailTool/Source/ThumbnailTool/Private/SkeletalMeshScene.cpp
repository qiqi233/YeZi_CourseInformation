#include "SkeletalMeshScene.h"
#include "Animation/SkeletalMeshActor.h"


FSkeletalMeshScene::FSkeletalMeshScene(IPreviewSceneBase::ConstructionValues CVS/* = ConstructionValues()*/)
	:IPreviewSceneBase(CVS)
{
	SceneType = ESceneType::SkeletalMesh;
	FActorSpawnParameters SpawnParameters;
	SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SkeletalMeshActor = GetWorld()->SpawnActor<ASkeletalMeshActor>(SpawnParameters);
	//SkeletalMeshActor
	ViewZoom = 0;
}

void FSkeletalMeshScene::AddReferencedObjects(FReferenceCollector& Collector)
{
	if (SkeletalMeshActor)
	{
		Collector.AddReferencedObject(SkeletalMeshActor);
	}
}


void FSkeletalMeshScene::SetMesh(UObject* DiffMesh)
{
	if (DiffMesh)
	{
		USkeletalMesh*SkeletalMesh = Cast<USkeletalMesh>(DiffMesh);
		SkeletalMeshActor->GetSkeletalMeshComponent()->SetSkeletalMesh(SkeletalMesh);
		SkeletalMeshActor->GetSkeletalMeshComponent()->UpdateBounds();
	}
}

FBoxSphereBounds FSkeletalMeshScene::GetBoundingBox()
{
	FBoxSphereBounds Bounds(ForceInitToZero);
	if (SkeletalMeshActor&&SkeletalMeshActor->GetSkeletalMeshComponent()->SkeletalMesh)
	{
		Bounds = SkeletalMeshActor->GetSkeletalMeshComponent()->SkeletalMesh->GetBounds();
	}
	return Bounds;
}

FSkeletalMeshScene::~FSkeletalMeshScene()
{

}

