#include "CustomMeshScene.h"

FCustomMeshScene::FCustomMeshScene(IPreviewSceneBase::ConstructionValues CVS/* = ConstructionValues()*/)
	:IPreviewSceneBase(CVS)
{
	SceneType = ESceneType::ProceduralMesh;
	FActorSpawnParameters SpawnParameters;
	SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	CustomMeshActor = GetWorld()->SpawnActor<ACustomMeshActor>(SpawnParameters);
	ViewZoom = 10;
}

void FCustomMeshScene::AddReferencedObjects(FReferenceCollector& Collector)
{
	if (CustomMeshActor)
	{
		Collector.AddReferencedObject(CustomMeshActor);
	}
}


void FCustomMeshScene::SetMesh(UObject* DiffMesh)
{


}

FBoxSphereBounds FCustomMeshScene::GetBoundingBox()
{
	FBoxSphereBounds Bounds(ForceInitToZero);
	return Bounds;
}

FCustomMeshScene::~FCustomMeshScene()
{

}

