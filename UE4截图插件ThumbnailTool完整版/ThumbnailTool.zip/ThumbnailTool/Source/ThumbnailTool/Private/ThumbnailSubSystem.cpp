#include "ThumbnailSubSystem.h"
#include "Engine/StaticMesh.h"
#include "SkeletalMeshScene.h"
#include "StaticMeshScene.h"
#include "CustomMeshScene.h"
void UThumbnailSystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

}

void UThumbnailSystem::Deinitialize()
{
	Super::Deinitialize();
	for (TSharedPtr<IPreviewSceneBase>& Scene : PreviewSceneArray)
	{
		Scene = nullptr;
	}
}

void UThumbnailSystem::CaptureSkeletalMesh(USkeletalMesh* SkeletalMesh, int32 SizeX, int32 SizeY)
{
	TSharedRef<IPreviewSceneBase>PreviewScene= GetPreviewSceneByType(ESceneType::SkeletalMesh);

	PreviewScene->CaptureSceneImage(SkeletalMesh, SizeX, SizeY);
}

void UThumbnailSystem::CaptureStaticMesh(UStaticMesh* StaticMesh, int32 SizeX, int32 SizeY)
{
	TSharedRef<IPreviewSceneBase>PreviewScene = GetPreviewSceneByType(ESceneType::StaticMesh);
	PreviewScene->CaptureSceneImage(StaticMesh, SizeX, SizeY);
}

void UThumbnailSystem::CaptureCustomMesh(int32 SizeX, int32 SizeY)
{

}

TSharedRef<IPreviewSceneBase> UThumbnailSystem::ConstructMeshScene(ESceneType SceneType)
{
	TSharedPtr<IPreviewSceneBase> PreviewSceneBase;
	IPreviewSceneBase::ConstructionValues CS;
	//ע��������������true,��ô����������ǽز���ͼƬ�ģ���������һ��Ҫ�ĳ�false
	CS.bEditor = false;
	switch (SceneType)
	{
	case ESceneType::SkeletalMesh:
		PreviewSceneBase = MakeShareable(new FSkeletalMeshScene(CS));
		break;
	case ESceneType::StaticMesh:
		PreviewSceneBase = MakeShareable(new FStaticMeshScene(CS));
		break;
	case ESceneType::ProceduralMesh:
		PreviewSceneBase = MakeShareable(new FCustomMeshScene(CS));
		break;
	}
	PreviewSceneArray.Add(PreviewSceneBase);
	return PreviewSceneBase.ToSharedRef();
}

TSharedRef<IPreviewSceneBase> UThumbnailSystem::GetPreviewSceneByType(ESceneType SceneType)
{
	for (auto& Scene : PreviewSceneArray)
	{
		if (Scene->SceneType == SceneType)
		{
			return Scene.ToSharedRef();
		}
	}
	return ConstructMeshScene(SceneType);
}

