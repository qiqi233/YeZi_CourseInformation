#include "CustomMeshActor.h"
#include "ProceduralMeshComponent.h"
ACustomMeshActor::ACustomMeshActor()
{
	RootComponent = NewObject<USceneComponent>(GetTransientPackage(), "MyRootComponent");
	ProceduralMeshCom = NewObject<UProceduralMeshComponent>(GetTransientPackage(), "ProceduralMeshCom");
	ProceduralMeshCom->AttachTo(RootComponent);
}

UProceduralMeshComponent* ACustomMeshActor::GetProceduralMeshComponent() const
{
	return ProceduralMeshCom;
}