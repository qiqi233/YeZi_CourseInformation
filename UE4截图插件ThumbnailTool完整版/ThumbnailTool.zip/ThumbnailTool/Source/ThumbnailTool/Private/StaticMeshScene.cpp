#include "StaticMeshScene.h"
#include "Engine/StaticMeshActor.h"

FStaticMeshScene::FStaticMeshScene(IPreviewSceneBase::ConstructionValues CVS /*= ConstructionValues()*/)
	:IPreviewSceneBase(CVS)
{
	SceneType = ESceneType::StaticMesh;
	FActorSpawnParameters SpawnParameters;
	SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	StaticMeshActor = PreviewWorld->SpawnActor<AStaticMeshActor>(SpawnParameters);
	ViewZoom = 10;
}

FStaticMeshScene::~FStaticMeshScene()
{

}

void FStaticMeshScene::AddReferencedObjects(FReferenceCollector& Collector)
{
	if (StaticMeshActor)
	{
		Collector.AddReferencedObject(StaticMeshActor);
	}
}

void FStaticMeshScene::SetMesh(UObject* DiffMesh)
{
	if (DiffMesh)
	{
		UStaticMesh* StaticMesh = Cast<UStaticMesh>(DiffMesh);
		StaticMeshActor->GetStaticMeshComponent()->SetStaticMesh(StaticMesh);
		StaticMeshActor->GetStaticMeshComponent()->UpdateBounds();
	}
}

FBoxSphereBounds FStaticMeshScene::GetBoundingBox()
{
	FBoxSphereBounds Bounds(ForceInitToZero);
	if (StaticMeshActor&&StaticMeshActor->GetStaticMeshComponent()->GetStaticMesh())
	{
		Bounds = StaticMeshActor->GetStaticMeshComponent()->GetStaticMesh()->GetBounds();
	}
	return Bounds;
}

