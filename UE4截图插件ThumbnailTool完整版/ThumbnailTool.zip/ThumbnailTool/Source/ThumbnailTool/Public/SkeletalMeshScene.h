#pragma once
#include "PreviewSceneBase.h"


class FSkeletalMeshScene final :public IPreviewSceneBase
{
public:
	FSkeletalMeshScene(IPreviewSceneBase::ConstructionValues CVS = ConstructionValues());
	virtual ~FSkeletalMeshScene();

private:
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override ;
	virtual void SetMesh(UObject* DiffMesh) override;
	virtual FBoxSphereBounds GetBoundingBox() override;

private:
	class ASkeletalMeshActor* SkeletalMeshActor;
};