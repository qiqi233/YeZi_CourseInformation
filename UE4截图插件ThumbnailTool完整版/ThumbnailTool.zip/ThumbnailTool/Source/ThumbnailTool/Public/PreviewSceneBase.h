#pragma once
#include "PreviewScene.h"

enum ESceneType 
{
	NONE,
	SkeletalMesh,
	StaticMesh,
	ProceduralMesh,
	CustomMesh=1000,
};
class IMeshBoundingBox
{
public:
	virtual FBoxSphereBounds GetBoundingBox() = 0;
	//...
};
class IPreviewSceneBase :public FPreviewScene, IMeshBoundingBox
{
public:
	IPreviewSceneBase(ConstructionValues CVS = ConstructionValues());
	void CaptureSceneImage(UObject* DiffMesh, int32 SizeX, int32 SizeY);

	virtual ~IPreviewSceneBase() {}
protected:
	virtual void SetMesh(UObject* DiffMesh) {};

	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	void DrawCanvas(uint32 Width, uint32 Height, FRenderTarget* RenderTarget, FCanvas* Canvas);
	void CalculationView(FSceneViewFamily* ViewFamily, int32 X, int32 Y, uint32 SizeX, uint32 SizeY);
	void ConstructWorld();
private:
	void SerialiszeImage(int32 Width, int32 Height, const uint8 *Data, const FString& InImageName, bool bSaveJpgOnly = false);
	void SaveImage(UTextureRenderTarget2D *Texture, const FString& InImageName);
public:
	ESceneType			SceneType;
protected:
	//�ӿڷ���
	FRotator              ViewDir;
	//�ӿھ���۲����ݲ�
	float                 ViewZoom;
	FString				  ImageName;
private:
	UTextureRenderTarget2D* TexRenderTarget;
};