#pragma once
#include "CoreMinimal.h"
#include "CustomMeshActor.generated.h"

UCLASS()
class THUMBNAILTOOL_API ACustomMeshActor :public AActor
{
	GENERATED_BODY()
public:
	ACustomMeshActor();
	UFUNCTION()
	UProceduralMeshComponent* GetProceduralMeshComponent() const;
private:
	UPROPERTY()
		class UProceduralMeshComponent* ProceduralMeshCom;

};