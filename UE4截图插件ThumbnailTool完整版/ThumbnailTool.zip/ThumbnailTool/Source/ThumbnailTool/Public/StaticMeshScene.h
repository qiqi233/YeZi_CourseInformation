#pragma once
#include "PreviewSceneBase.h"

 class FStaticMeshScene final:public IPreviewSceneBase
{
public:
	FStaticMeshScene(IPreviewSceneBase::ConstructionValues CVS = ConstructionValues());
	virtual ~FStaticMeshScene();
private:
	virtual void AddReferencedObjects(FReferenceCollector& Collector) override;
	virtual void SetMesh(UObject* DiffMesh) override;
	virtual FBoxSphereBounds GetBoundingBox() override;
private:
	class AStaticMeshActor* StaticMeshActor;
};